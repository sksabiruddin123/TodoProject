package com.gl.todo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gl.todo.dto.TodoDto;
import com.gl.todo.service.TodoService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;


@CrossOrigin("*")
@RestController
@RequestMapping("api/todos")
public class TodoController {
	
	@Autowired
	private TodoService todoService;
	
	@PostMapping
	public ResponseEntity<TodoDto> createTodo(@RequestBody TodoDto tododto){
		
		TodoDto savedTodo = todoService.createTodo(tododto);
		
		return new ResponseEntity<>(savedTodo,HttpStatus.CREATED);
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<TodoDto> getTodoById(@PathVariable int id){
		
		TodoDto todoDto = todoService.getTodoById(id);
		
		if (todoDto !=null)  return ResponseEntity.ok(todoDto);
		      else           return	ResponseEntity.notFound().build();	
	}
	
	@GetMapping
	public ResponseEntity<List<TodoDto>> getAllTodos(){
		
		List<TodoDto> todos = todoService.getAllTodos();
		
		return ResponseEntity.ok(todos);
	}
	
	

    @PutMapping("/{id}")
    public ResponseEntity<TodoDto> updateTodo(@PathVariable int id, 
    		                                @RequestBody TodoDto todoDto){
    	
    	TodoDto updatedTodo=todoService.updateTodo(id, todoDto);
    	
    	if(updatedTodo != null) {
    		return ResponseEntity.ok(updatedTodo);
    	}
    	return ResponseEntity.notFound().build();
    	
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteTodo(@PathVariable int id) {
        todoService.deleteTodo(id);
        return ResponseEntity.noContent().build();
    }
	
	@PatchMapping("{id}/complete")
	public ResponseEntity<TodoDto> completeTodo(@PathVariable int id){
	
	TodoDto completedTodo = todoService.completeTodo(id);
	 if (completedTodo != null)  
		 return ResponseEntity.ok(completedTodo);
                else           
                	return ResponseEntity.notFound().build();
     
	
	}
	
	@PatchMapping("{id}/incomplete")
	public ResponseEntity<TodoDto> incompleteTodo(@PathVariable int id){
	
	TodoDto completedTodo = todoService.incompleteTodo(id);
	 if (completedTodo != null)  
		 return ResponseEntity.ok(completedTodo);
                else           
                	return ResponseEntity.notFound().build();
     
	
	}

}










