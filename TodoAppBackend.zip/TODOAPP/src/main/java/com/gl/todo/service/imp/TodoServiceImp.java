package com.gl.todo.service.imp;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gl.todo.dto.TodoDto;
import com.gl.todo.entity.ToDo;
import com.gl.todo.mapper.TodoMapper;
import com.gl.todo.repository.ToDoRepository;
import com.gl.todo.service.TodoService;

@Service
public class TodoServiceImp  implements TodoService{
	
   @Autowired	
   private ToDoRepository todoRepository;

   //Create Method
	@Override
	public TodoDto createTodo(TodoDto todoDto) {
		
		ToDo todo = TodoMapper.mapDtoToEntity(todoDto);
		ToDo savedTodo = todoRepository.save(todo);	
		return TodoMapper.mapEntitytoDto(savedTodo);
	}
	

	//Get Method By ID
	@Override
	public TodoDto getTodoById(int id) {
		
		 Optional<ToDo> todoOptional = todoRepository.findById(id);
		 
	     if (todoOptional.isPresent()) {
	            return TodoMapper.mapEntitytoDto(todoOptional.get());
	        }
	        return null;
	}

	//Get All Method
	@Override
	public List<TodoDto> getAllTodos() {
		
		List<ToDo>  todos = todoRepository.findAll();
		
		return todos.stream().
		            map((todo) -> TodoMapper.mapEntitytoDto(todo)).
		            collect(Collectors.toList());
	}

	//Update Method
	@Override
	public TodoDto updateTodo(int id, TodoDto todoDto) {
		
	  Optional<ToDo> todoOptional = todoRepository.findById(id);
	  
	  if (todoOptional.isPresent()) {
          
		  ToDo todo = todoOptional.get();
		  
		  todo.setTitle(todoDto.getTitle());
		  todo.setDescription(todoDto.getDescription());
          todo.setCompleted(todoDto.isCompleted());
          
          todo = todoRepository.save(todo);
          
          return TodoMapper.mapEntitytoDto(todo);
          
      }
      return null;
		
		
	}

	//Delete Method
	@Override
	public void deleteTodo(int id) {
		
		todoRepository.deleteById(id);
		
	}

	// Complete Method
	@Override
	public TodoDto completeTodo(int id) {
	
	  Optional<ToDo> todoOptional = todoRepository.findById(id);
	  
	  if(todoOptional.isPresent()) {
		  
		  ToDo todo = todoOptional.get();
		  todo.setCompleted(true);
		  todo = todoRepository.save(todo);
		  
		  return TodoMapper.mapEntitytoDto(todo);
	  }
	  
	  return null;
		
	}

	//Incomplete Method
	@Override
	public TodoDto incompleteTodo(int id) {
		
		 Optional<ToDo> todoOptional = todoRepository.findById(id);
		 
		  if(todoOptional.isPresent()) {
			  
			  ToDo todo = todoOptional.get();
			  todo.setCompleted(false);
			  todo = todoRepository.save(todo);
			  
			  return TodoMapper.mapEntitytoDto(todo);
		  }
		  
		  return null;
			
		
	}

}
