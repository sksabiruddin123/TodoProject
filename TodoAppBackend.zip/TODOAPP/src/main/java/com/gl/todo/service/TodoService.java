package com.gl.todo.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.gl.todo.dto.TodoDto;

@Service
public interface TodoService {
	
	TodoDto createTodo(TodoDto todoDto);
	
    TodoDto	getTodoById(int id);
    
    List<TodoDto> getAllTodos();
    
    TodoDto updateTodo(int id, TodoDto todoDto);
		 
	void deleteTodo(int id);
	
	TodoDto completeTodo(int id);
	
	TodoDto incompleteTodo(int id);
	 
	 
	 

}
