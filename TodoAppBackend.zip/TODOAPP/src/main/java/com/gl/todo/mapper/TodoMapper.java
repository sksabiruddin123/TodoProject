package com.gl.todo.mapper;

import com.gl.todo.dto.TodoDto;
import com.gl.todo.entity.ToDo;

public class TodoMapper {
	
	public static TodoDto mapEntitytoDto(ToDo todo) {
		
		return new TodoDto(
				  todo.getId(),
				  todo.getTitle(),
		          todo.getDescription(),
		          todo.isCompleted()
		          );	
	}
	
	public static ToDo mapDtoToEntity(TodoDto todoDto) {
		
		return new ToDo(
				    todoDto.getId(),
				    todoDto.getTitle(),
				    todoDto.getDescription(),
				    todoDto.isCompleted()		    
				);
		
	}

}
